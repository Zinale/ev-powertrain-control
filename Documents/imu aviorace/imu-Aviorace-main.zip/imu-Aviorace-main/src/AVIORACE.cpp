// AVIORACE.cpp
#include <CAN.h>
#include <CANSAME5x.h>
#include "AVIORACE.h"

#define PRINT_RAW_DATA 1

extern CANSAME5x CAN;
extern imu_actual_values actual_values;
extern imu_info info;

void init_device()
{
    Serial.begin(115200);
    
    pinMode(PIN_CAN_STANDBY, OUTPUT);
    digitalWrite(PIN_CAN_STANDBY, false); // turn off STANDBY
    pinMode(PIN_CAN_BOOSTEN, OUTPUT);
    digitalWrite(PIN_CAN_BOOSTEN, true); // turn on booster

    // avvia il can bus a 500kbps
    if (!CAN.begin(500000))
    {
        Serial.printf("Starting CAN failed!\n");
        // se la comunicazione non avviene correttamente il led lampeggia
        while (1)
        {
            digitalWrite(LED_BUILTIN, HIGH);
            delay(200);
            digitalWrite(LED_BUILTIN, LOW);
            delay(200);
        }
    }

    set_imu();
}

bool send_message(uint8_t* message, size_t address)
{
    Serial.printf("Sending packet to ...0x%X\n", address);
    CAN.beginPacket(address);
    size_t bytesSent = CAN.write(message, 8);
    CAN.endPacket();
    return (bytesSent == 8);
}

void set_imu()
{
    // // get imu info (serve per riempire lo struct info e recuperare il valore di positioning)
    // uint8_t get_imu_info[8] = {0x01, 0XA2, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA};
    // if(send_message(get_imu_info, REPROGRAM_ID))
    // {
    //     Serial.printf("Got info!\n");
    // }
    // else{
    //     while(1)
    //     {
    //         Serial.printf("Error getting imu info!\n");
    //     }
    // }


    //reprogram_data
    uint8_t reprogram_data[8] = {0x01, 0xA0, 0xAA, ACC_RANGE, GYRO_RANGE, BAUD_RATE, (BASE_ID >> 8) & 0xFF, BASE_ID & 0xFF};
    //positioning_data
    uint8_t positioning_data[8] = {0x01, 0xA3, 0xAA, 0xAA, 0xAA, 0x00, ACC_FREQ, GYRO_FREQ};
    //messaggio relativo al reprogram data
    if(send_message(reprogram_data, REPROGRAM_ID) && 
        send_message(positioning_data, REPROGRAM_ID)){
        Serial.printf("Imu set!\n");
    }
    else{
        while(1){
            Serial.printf("Error setting imu!\n");
        }
    }

}


void receive_message(int packetSize)
{
    long packet_ID = CAN.packetId();
    Serial.printf("Received CAN packet from...0x%X\n", packet_ID);

    if (CAN.available() >= packetSize)
    {
        actual_values.value_x = (CAN.read() << 8) | CAN.read();
        actual_values.value_y = (CAN.read() << 8) | CAN.read();
        actual_values.value_z = (CAN.read() << 8) | CAN.read();
        actual_values.tail = (CAN.read() << 8) | CAN.read();
    }
    else
    {
        Serial.println("Invalid packet size");
        return;
    }

    process_actual_values(&actual_values, packet_ID);
}

void process_actual_values(const imu_actual_values *actual, long packet_ID)
{
   #ifdef PRINT_RAW_DATA
    Serial.printf(
            "Non formatted data: %d, %d, %d, %d \n",
            actual->value_x,
            actual->value_y,
            actual->value_z,
            actual->tail
        );
    #endif
    if (packet_ID == ACC_ID)
    {
        Serial.printf(
            "Acceleration: %f G, %f G, %f G, Serial: %d \n",
            (float) actual->value_x * 0.0001f,
            (float) actual->value_y * 0.0001f,
            (float) actual->value_z * 0.0001f,
            actual->tail
        );
    }
    else if (packet_ID == GYRO_ID)
    {
        Serial.printf(
            "Gyroscope: %f °/s, %f °/s, %f °/s, Internal Temp: %f °C\n",
            (float) actual->value_x * 0.1f,
            (float) actual->value_y * 0.1f,
            (float) actual->value_z * 0.1f,
            (float) actual->tail * 0.1f
        );
    }
    else if (packet_ID == MAG_ID)
    {
        Serial.printf(
            "Magnetometer: %f uT, %f uT, %f uT\n",
            (float) actual->value_x * 0.01f,
            (float) actual->value_y * 0.01f,
            (float) actual->value_z * 0.01f
        );
    }
    else if(packet_ID == IMU_INFO_ID)
    {
        info.fw_version = ((CAN.read() << 8) | CAN.read()) * 0.01;
        info.acc_range = CAN.read();
        info.gyro_range = CAN.read();
        info.acc_freq = CAN.read();
        info.gyro_freq = CAN.read();
        info.positioning = CAN.read();
        info.bootloader_version = CAN.read() * 0.1;
    }
    
}
