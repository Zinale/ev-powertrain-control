// AVIORACE.h
#ifndef AVIORACE_H
#define AVIORACE_H

#include <Arduino.h>

#define BASE_ID 0x0000

#define ACC_ID (BASE_ID + 0x0)
#define GYRO_ID (BASE_ID + 0x1)
#define MAG_ID (BASE_ID + 0x2)
#define IMU_INFO_ID 0x0E4

// reprogram data bytes
#define BAUD_RATE 0x01
#define GYRO_RANGE 0x01
#define ACC_RANGE 0x02

// positioning bytes
#define GYRO_FREQ 0x01
#define ACC_FREQ 0x01

#define REPROGRAM_ID 0x0E5

typedef struct
{
    int16_t value_x;
    int16_t value_y;
    int16_t value_z;
    int16_t tail;
} imu_actual_values;

typedef struct{
    int16_t fw_version;
    int8_t acc_range;
    int8_t gyro_range;
    int8_t acc_freq;
    int8_t gyro_freq;
    int8_t positioning;
    int8_t bootloader_version;
} imu_info;

void init_device();
bool send_message(uint8_t *message, size_t address);
void set_imu();
void receive_message(int packetSize);
void process_actual_values(const imu_actual_values *actual, long packet_ID);

#endif
